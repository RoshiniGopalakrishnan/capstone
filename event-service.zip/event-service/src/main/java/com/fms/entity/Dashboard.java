package com.fms.entity;

import lombok.Data;

@Data
public class Dashboard {

	private String totalEvents;

	private String livesImpacted;

	private String totalVolunteers;

	private String totalParticipants;

//	public String getTotalEvents() {
//		return totalEvents;
//	}
//
//	public void setTotalEvents(String totalEvents) {
//		this.totalEvents = totalEvents;
//	}
//
//	public String getLivesImpacted() {
//		return livesImpacted;
//	}
//
//	public void setLivesImpacted(String livesImpacted) {
//		this.livesImpacted = livesImpacted;
//	}
//
//	public String getTotalVolunteers() {
//		return totalVolunteers;
//	}
//
//	public void setTotalVolunteers(String totalVolunteers) {
//		this.totalVolunteers = totalVolunteers;
//	}
//
//	public String getTotalParticipants() {
//		return totalParticipants;
//	}
//
//	public void setTotalParticipants(String totalParticipants) {
//		this.totalParticipants = totalParticipants;
//	}
//
//	public Dashboard(String totalEvents, String livesImpacted, String totalVolunteers, String totalParticipants) {
//		super();
//		this.totalEvents = totalEvents;
//		this.livesImpacted = livesImpacted;
//		this.totalVolunteers = totalVolunteers;
//		this.totalParticipants = totalParticipants;
//	}
//
//	@Override
//	public String toString() {
//		return "Dashboard [totalEvents=" + totalEvents + ", livesImpacted=" + livesImpacted + ", totalVolunteers="
//				+ totalVolunteers + ", totalParticipants=" + totalParticipants + "]";
//	}
//
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((livesImpacted == null) ? 0 : livesImpacted.hashCode());
//		result = prime * result + ((totalEvents == null) ? 0 : totalEvents.hashCode());
//		result = prime * result + ((totalParticipants == null) ? 0 : totalParticipants.hashCode());
//		result = prime * result + ((totalVolunteers == null) ? 0 : totalVolunteers.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Dashboard other = (Dashboard) obj;
//		if (livesImpacted == null) {
//			if (other.livesImpacted != null)
//				return false;
//		} else if (!livesImpacted.equals(other.livesImpacted))
//			return false;
//		if (totalEvents == null) {
//			if (other.totalEvents != null)
//				return false;
//		} else if (!totalEvents.equals(other.totalEvents))
//			return false;
//		if (totalParticipants == null) {
//			if (other.totalParticipants != null)
//				return false;
//		} else if (!totalParticipants.equals(other.totalParticipants))
//			return false;
//		if (totalVolunteers == null) {
//			if (other.totalVolunteers != null)
//				return false;
//		} else if (!totalVolunteers.equals(other.totalVolunteers))
//			return false;
//		return true;
//	}

	
}