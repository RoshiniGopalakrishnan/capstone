package com.events.api;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.events.model.EventReport;

public interface EventsApiRepository extends ReactiveCrudRepository<EventReport, Integer> {

}
