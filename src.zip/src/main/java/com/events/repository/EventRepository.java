package com.events.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.events.model.EventReport;


/**
 * @author 805896
 *
 */
@Repository
public interface EventRepository extends ReactiveCrudRepository<EventReport, Integer> {

}
