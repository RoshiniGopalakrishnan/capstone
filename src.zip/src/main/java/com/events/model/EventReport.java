package com.events.model;

import java.util.Date;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.springframework.validation.annotation.Validated;

import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Event
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2020-02-24T16:58:46.104+05:30[Asia/Calcutta]")
@Table(name="event_report")
public class EventReport   {
  @JsonProperty("id")
  private Integer id;

  @JsonProperty("event_id")
  private String eventId = null;

  public String getIiepCategory() {
	return iiepCategory;
}

public void setIiepCategory(String iiepCategory) {
	this.iiepCategory = iiepCategory;
}

@JsonProperty("iiep_category")
  private String iiepCategory = null;

  @JsonProperty("base_location")
  private String baseLocation = null;

  @JsonProperty("council_name")
  private String councilName = null;

  @JsonProperty("beneficiary_name")
  private String beneficiaryName = null;

  @JsonProperty("event_name")
  private String eventName = null;

  @JsonProperty("event_date")
  private Date eventDate = null;

  @JsonProperty("event_description")
  private String eventDescription = null;

  @JsonProperty("employee_id")
  private Integer employeeId = null;

  @JsonProperty("employee_name")
  private String employeeName = null;

  @JsonProperty("buisness_unit")
  private String businessUnit = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("volunteer_hours")
  private Integer volunteerHours = null;

  @JsonProperty("travel_hours")
  private Integer travelHours = null;

  @JsonProperty("lives_impacted")
  private Integer livesImpacted = null;

  public EventReport id(Integer id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public EventReport eventId(String eventId) {
    this.eventId = eventId;
    return this;
  }

  /**
   * Get eventId
   * @return eventId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getEventId() {
    return eventId;
  }

  public void setEventId(String eventId) {
    this.eventId = eventId;
  }



  /**
   * Get category
   * @return category
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull


  

  public EventReport baseLocation(String baseLocation) {
    this.baseLocation = baseLocation;
    return this;
  }

  /**
   * Get baseLocation
   * @return baseLocation
  **/
  @ApiModelProperty(example = "United Kingdom", required = true, value = "")
      @NotNull

    public String getBaseLocation() {
    return baseLocation;
  }

  public void setBaseLocation(String baseLocation) {
    this.baseLocation = baseLocation;
  }

  public EventReport councilName(String councilName) {
    this.councilName = councilName;
    return this;
  }

  /**
   * Get councilName
   * @return councilName
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getCouncilName() {
    return councilName;
  }

  public void setCouncilName(String councilName) {
    this.councilName = councilName;
  }

  public EventReport beneficiaryName(String beneficiaryName) {
    this.beneficiaryName = beneficiaryName;
    return this;
  }

  /**
   * Get beneficiaryName
   * @return beneficiaryName
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getBeneficiaryName() {
    return beneficiaryName;
  }

  public void setBeneficiaryName(String beneficiaryName) {
    this.beneficiaryName = beneficiaryName;
  }

  public EventReport eventName(String eventName) {
    this.eventName = eventName;
    return this;
  }

  /**
   * Get eventName
   * @return eventName
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  public EventReport eventDate(Date eventDate) {
    this.eventDate = eventDate;
    return this;
  }

  /**
   * Get eventDate
   * @return eventDate
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    @Valid
    public Date getEventDate() {
    return eventDate;
  }

  public void setEventDate(Date eventDate) {
    this.eventDate = eventDate;
  }

  public EventReport eventDescription(String eventDescription) {
    this.eventDescription = eventDescription;
    return this;
  }

  /**
   * Get eventDescription
   * @return eventDescription
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getEventDescription() {
    return eventDescription;
  }

  public void setEventDescription(String eventDescription) {
    this.eventDescription = eventDescription;
  }

  public EventReport employeeId(Integer employeeId) {
    this.employeeId = employeeId;
    return this;
  }

  /**
   * Get employeeId
   * @return employeeId
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public Integer getEmployeeId() {
    return employeeId;
  }

  public void setEmployeeId(Integer employeeId) {
    this.employeeId = employeeId;
  }

  public EventReport employeeName(String employeeName) {
    this.employeeName = employeeName;
    return this;
  }

  /**
   * Get employeeName
   * @return employeeName
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getEmployeeName() {
    return employeeName;
  }

  public void setEmployeeName(String employeeName) {
    this.employeeName = employeeName;
  }

  public EventReport businessUnit(String businessUnit) {
    this.businessUnit = businessUnit;
    return this;
  }

  /**
   * Get businessUnit
   * @return businessUnit
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getBusinessUnit() {
    return businessUnit;
  }

  public void setBusinessUnit(String businessUnit) {
    this.businessUnit = businessUnit;
  }

  public EventReport status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public EventReport volunteerHours(Integer volunteerHours) {
    this.volunteerHours = volunteerHours;
    return this;
  }

  /**
   * Get volunteerHours
   * @return volunteerHours
  **/
  @ApiModelProperty(value = "")
  
    public Integer getVolunteerHours() {
    return volunteerHours;
  }

  public void setVolunteerHours(Integer volunteerHours) {
    this.volunteerHours = volunteerHours;
  }

  public EventReport travelHours(Integer travelHours) {
    this.travelHours = travelHours;
    return this;
  }

  /**
   * Get travelHours
   * @return travelHours
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public Integer getTravelHours() {
    return travelHours;
  }

  public void setTravelHours(Integer travelHours) {
    this.travelHours = travelHours;
  }

  public EventReport livesImpacted(Integer livesImpacted) {
    this.livesImpacted = livesImpacted;
    return this;
  }

  /**
   * Get livesImpacted
   * @return livesImpacted
  **/
  @ApiModelProperty(required = true, value = "")
      @NotNull

    public Integer getLivesImpacted() {
    return livesImpacted;
  }

  public void setLivesImpacted(Integer livesImpacted) {
    this.livesImpacted = livesImpacted;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EventReport event = (EventReport) o;
    return Objects.equals(this.id, event.id) &&
        Objects.equals(this.eventId, event.eventId) &&
        
        Objects.equals(this.baseLocation, event.baseLocation) &&
        Objects.equals(this.councilName, event.councilName) &&
        Objects.equals(this.beneficiaryName, event.beneficiaryName) &&
        Objects.equals(this.eventName, event.eventName) &&
        Objects.equals(this.eventDate, event.eventDate) &&
        Objects.equals(this.eventDescription, event.eventDescription) &&
        Objects.equals(this.employeeId, event.employeeId) &&
        Objects.equals(this.employeeName, event.employeeName) &&
        Objects.equals(this.businessUnit, event.businessUnit) &&
        Objects.equals(this.status, event.status) &&
        Objects.equals(this.volunteerHours, event.volunteerHours) &&
        Objects.equals(this.travelHours, event.travelHours) &&
        Objects.equals(this.livesImpacted, event.livesImpacted);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, eventId, baseLocation, councilName, beneficiaryName, eventName, eventDate, eventDescription, employeeId, employeeName, businessUnit, status, volunteerHours, travelHours, livesImpacted);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Event {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    eventId: ").append(toIndentedString(eventId)).append("\n");

    sb.append("    baseLocation: ").append(toIndentedString(baseLocation)).append("\n");
    sb.append("    councilName: ").append(toIndentedString(councilName)).append("\n");
    sb.append("    beneficiaryName: ").append(toIndentedString(beneficiaryName)).append("\n");
    sb.append("    eventName: ").append(toIndentedString(eventName)).append("\n");
    sb.append("    eventDate: ").append(toIndentedString(eventDate)).append("\n");
    sb.append("    eventDescription: ").append(toIndentedString(eventDescription)).append("\n");
    sb.append("    employeeId: ").append(toIndentedString(employeeId)).append("\n");
    sb.append("    employeeName: ").append(toIndentedString(employeeName)).append("\n");
    sb.append("    businessUnit: ").append(toIndentedString(businessUnit)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    volunteerHours: ").append(toIndentedString(volunteerHours)).append("\n");
    sb.append("    travelHours: ").append(toIndentedString(travelHours)).append("\n");
    sb.append("    livesImpacted: ").append(toIndentedString(livesImpacted)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
