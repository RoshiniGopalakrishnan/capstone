package com.fms.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.fms.model.User;

/**
 * @author 805896
 *
 */
@Repository
public interface UserRepository extends ReactiveCrudRepository<User, Integer> {
	User findByUsername(String empId);
}
